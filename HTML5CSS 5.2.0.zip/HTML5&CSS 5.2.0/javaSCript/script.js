function mostraMenu() {
    document.getElementById("navlinks").classList.add("show");
}

function fechaMenu() {
    document.getElementById("navlinks").classList.remove("show");
}
