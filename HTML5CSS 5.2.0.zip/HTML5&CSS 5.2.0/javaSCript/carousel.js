
document.addEventListener("DOMContentLoaded", function () {
    let carousel = document.getElementById("carouselExampleFade");
    let body = document.body;
    let container = document.querySelector('.container-fluid'); // Alterado para 'container-fluid'

    // Cores para cada slide
    let colors = ["#66a4d7", "#ffde59", "#c2b59b"]; // Defina as cores desejadas

    // Evento disparado quando o slide começa a mudar
    carousel.addEventListener("slide.bs.carousel", function (event) {
        let activeIndex = event.to; // Obtém o índice do próximo slide

        // Altera a cor de fundo do body e do container
        if (activeIndex !== -1) {
            body.style.backgroundColor = colors[activeIndex];
            container.style.backgroundColor = colors[activeIndex];
        }
    });
});
